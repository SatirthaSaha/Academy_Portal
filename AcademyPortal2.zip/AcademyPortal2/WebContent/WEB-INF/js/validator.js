$(document).ready(function() {  // <-- enclose your code in a DOM ready handler


	jQuery.validator.addMethod("avail", function() {
		var bool=false;
		$.ajax({
			url:"checkEmail",
			data:{email:$("#email").val()},
			async:false,
			success: function(data){
				var m=data;
				if(m=="Email id is Available")
				{
					/*alert("In avail");*/
					bool=true;
				}
				if(m=="Email id is taken"){
					/*alert("In taken");*/
					bool=false;
				}
			}

		});
		/*alert(bool);*/
		return bool;
	})
	


	$("#signup-form").validate({
		rules: {
			"emailid":
			{
				required:true,
				avail:true,
				email:true
			},

		},
		messages: {
			
			"emailid":
			{
				required:"mandatory",
				avail:"Present",
				email:"Invalid"
			},


		},
		highlight: function(element) {
			$(element).parent().addClass('has-error');
		},
		unhighlight: function(element) {
			$(element).parent().removeClass('has-error');
		},
		errorClass:"errors"



	});

});